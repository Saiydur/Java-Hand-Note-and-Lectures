package Class;

public class Flat {
    private int randomId,floor,bedRoom,bathRoom,drawingRoom,dinningRoom,kitchen,belcony;
    private double rent;
    private boolean isRent;//false mean no one in this flat 
                           //true mean some one in this flat

    //default constructor
    public Flat()
    {
        this.rent=0.00;
    }

    //perameteraised constructor
    public Flat(int floor,int bedRoom,int bathRoom,int drawingRoom,int dinningRoom,int kitchen,int belcony,double rent,boolean isRent)
    {
        this.floor=floor;
        this.bathRoom=bathRoom;
        this.bedRoom=bedRoom;
        this.belcony=belcony;
        this.dinningRoom=dinningRoom;
        this.drawingRoom=drawingRoom;
        this.kitchen=kitchen;
        this.rent=rent;
        this.isRent=isRent;
    }

    //setter method
    public void setIsRent(boolean isRent)
    {
        this.isRent=isRent;
    }
    public void setRandomId(int randomId) {
        this.randomId = randomId;
    }
    public void setFloor(int floor) {
        this.floor = floor;
    }
    public void setBathRoom(int bathRoom) {
        this.bathRoom = bathRoom;
    }
    public void setBedRoom(int bedRoom) {
        this.bedRoom = bedRoom;
    }
    public void setBelcony(int belcony) {
        this.belcony = belcony;
    }
    public void setDinningRoom(int dinningRoom) {
        this.dinningRoom = dinningRoom;
    }
    public void setDrawingRoom(int drawingRoom) {
        this.drawingRoom = drawingRoom;
    }
    public void setKitchen(int kitchen) {
        this.kitchen = kitchen;
    }
    public void setRent(double rent) {
        this.rent = rent;
    }

    //getter method
    public boolean getIsRent()
    {
        return isRent;
    }
    public int getRandomId() {
        return randomId;
    }
    public int getFloor() {
        return floor;
    }
    public int getBathRoom() {
        return bathRoom;
    }
    public int getBedRoom() {
        return bedRoom;
    }
    public int getBelcony() {
        return belcony;
    }
    public int getDinningRoom() {
        return dinningRoom;
    }
    public int getDrawingRoom() {
        return drawingRoom;
    }
    public int getKitchen() {
        return kitchen;
    }
    public double getRent() {
        return rent;
    }

    public void showInfo()
    {
        System.out.println("------Flat Details------");
        System.out.println("Flaat Id:"+getRandomId());
        System.out.println("Flaat Floor:"+getFloor());
        System.out.println("Flaat Rent:"+getRent());
        System.out.println("Flaat Details:");
        System.out.println("Bed:"+getBedRoom()+" Bath:"+getBathRoom()+" Drawing:"+getDrawingRoom()+" Dinning:"+getDinningRoom()+" Kitcher:"+getKitchen()+" Belcony:"+getBelcony());
        System.out.println("------------------------");
    }
}
