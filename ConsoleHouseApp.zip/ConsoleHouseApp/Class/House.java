package Class;

import interfaces.*;

public class House implements OwnerIF{
    private  Flat[] flats = new Flat[10];
    private String houseLocation,holdingNumber;

    //default constructor
    public House()
    {
        this.houseLocation="";
        this.holdingNumber="";
    }

    //perameteraised constructor
    public House(String houseLocation,String holdingNumber)
    {
        this.holdingNumber=holdingNumber;
        this.houseLocation=houseLocation;
    }

    //setter method
    public void setFlats(Flat[] flats) {
        this.flats = flats;
    }
    public void setHoldingNumber(String holdingNumber) {
        this.holdingNumber = holdingNumber;
    }
    public void setHouseLocation(String houseLocation) {
        this.houseLocation = houseLocation;
    }

    //getter method
    public Flat[] getFlats() {
        return flats;
    }
    public String getHoldingNumber() {
        return holdingNumber;
    }
    public String getHouseLocation() {
        return houseLocation;
    }

    //add flat interface
    public  void addFlat(Flat f)
    {
        int flag=0;
        int randomId=0;
        for(int i=0;i<flats.length;i++)
        {
            if(flats[i]==null)
            {
                flats[i]=f;
                randomId=(int) (Math.random()*100000)+1;
                flats[i].setRandomId(randomId);
                flag=1;
                break;
            }
        }
        if(flag==1){System.out.println("Flat Added");
                    System.out.println("Flat Id Is:"+randomId);
        }
        else{System.out.println("Flat Not Added");}
    }

    public Flat getFlatDetails(int flatId)
    {
        int flag=0;
        Flat flat = null;
        for(int i=0;i<flats.length;i++)
        {
            if(flats[i]!=null)
            {
                if(flats[i].getRandomId()==flatId)
                {
                    flat=flats[i];
                    flag=1;
                    break;
                }
            }
        }
        if(flag==1)
        {
            System.out.println("Flat Found");
        }
        else
        {
            System.out.println("Flat Not Found");
        }
        return flat;
    }
    
    public void manageMonthlyBill(double flatRent,double waterBill,double electricBill,double gasBill,double serviceCharge)
    {
        double totalAmount = flatRent+waterBill+electricBill+gasBill+serviceCharge;
        System.out.println("-------Money Reciept-------");
        System.out.println("Flat Rent:"+flatRent);
        System.out.println("Water Bill:"+waterBill);
        System.out.println("Electric Bill:"+electricBill);
        System.out.println("Gas Bill:"+gasBill);
        System.out.println("Service Charge:"+serviceCharge);
        System.out.println("Total Amount To Paid:"+totalAmount);
    }

    public void showAllFlats()
    {
        for(Flat f : flats)
        {
            if(f!=null)
            {
                f.showInfo();
            }
        }
    }

    public void showHouse()
    {
        System.out.println("House Location:"+getHouseLocation());
        System.out.println("House Holding Number:"+getHoldingNumber());
        showAllFlats();
    }
}
