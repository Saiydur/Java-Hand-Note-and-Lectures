package Class;

public class Owner {
    private Integer nid;
    private String userName,fullName,password,email,contactNumber;

    public Owner()
    {
        nid=0;
    }

    //Perameteraised Constructor
    public Owner(String userName,String fullName,String password,String email,String contactNumber,Integer nid)
    {
        this.userName=userName;
        this.fullName=fullName;
        this.password=password;
        this.email=email;
        this.contactNumber=contactNumber;
        this.nid=nid;
    }

    //setter method
    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
    public void setNid(Integer nid) {
        this.nid = nid;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    
    //getter method
    public String getContactNumber() {
        return contactNumber;
    }
    public String getEmail() {
        return email;
    }
    public String getFullName() {
        return fullName;
    }
    public Integer getNid() {
        return nid;
    }
    public String getPassword() {
        return password;
    }
    public String getUserName() {
        return userName;
    }
}
