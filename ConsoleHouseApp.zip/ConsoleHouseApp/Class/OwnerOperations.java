package Class;


public class OwnerOperations {
    private static Owner[] owners = new Owner[10] ;
    private static House[] houses = new House[10];
    
    //setter and getter method
    public static void setOwners(Owner[] owners) {
        OwnerOperations.owners = owners;
    }
    public static Owner[] getOwners() {
        return owners;
    }

    //save Owner
    public static int save(Owner o)
    {
        int flag=0;
        for(int i=0;i<owners.length;i++)
        {
            if(owners[i]==null)
            {
                owners[i]=o;
                flag=1;
                break;
            }
            
        }
        return flag;
    }

    //checking user name and pass
    public static boolean validate(String userName,String password)
    {
        Boolean flag = false;
        for(int i=0;i<owners.length;i++)
        {
            if(owners[i]!=null)
            {
                if(owners[i].getUserName().equals(userName) && owners[i].getPassword().equals(password))
                {
                    flag=true;
                    break;
                }
            }
        }
        return flag;
    }

    public static void addHouse(House h)
    {
        int flag=0;
        for(int i=0;i<houses.length;i++)
        {
            if(houses[i]==null)
            {
                houses[i]=h;
                flag=1;
                break;
            }
        }
        if(flag==1){System.out.println("House Added");}
        else{System.out.println("House Not Added");}
    }
}
