package Class;

import interfaces.*;

public class TenantOperations implements TenantIF {
    private static Tenant[] tenants = new Tenant[10];
    //getter  and setter method
    public static void setTenants(Tenant[] tenants) {
        TenantOperations.tenants = tenants;
    }
    public static Tenant[] getTenants() {
        return tenants;
    }

    //save Tenant
    public static int save(Tenant t)
    {
        int flag=0;
        for(int i=0;i<tenants.length;i++)
        {
            if(tenants[i]==null)
            {
                tenants[i]=t;
                flag=1;
                break;
            }
        }
        return flag;
    }

    //checking user name and password
    public static boolean validate(String userName,String password)
    {
        Boolean flag = false;
        for(int i=0;i<tenants.length;i++)
        {
            if(tenants[i]!=null)
            {
                if(tenants[i].getUserName().equals(userName) && tenants[i].getPassword().equals(password))
                {
                    flag=true;
                    break;
                }
            }
        }
        return flag;
    }

    //rent a flat
    public void rentFlat(Flat f)
    {
        f.setIsRent(true);
        System.out.println("Flat Is Rent For You");
    }
}