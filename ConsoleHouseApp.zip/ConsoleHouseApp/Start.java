import java.io.IOException;
import java.util.Scanner;
import Class.*;
import interfaces.*;
import fileio.*;

public class Start{
    public static void main(String[] args) throws InterruptedException,IOException{
        Scanner sc = new Scanner(System.in);

        Thread ta = new Thread();
        FileReadWriteDemo frwd = new FileReadWriteDemo();

        new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        boolean choice = true;
        House h = new House();
        while(choice)
        {
            ta.sleep(1000);//1000ms = 1sec
            System.out.println("-----Select Your Option-----");
            System.out.println("1.Owner");//for Rent
            System.out.println("2.Tenant");//to Rent
            System.out.println("3.Exit");
            int first1 = sc.nextInt();
            sc.nextLine();
            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            switch(first1)
            {
                case 1:
                    Owner o = new Owner();
                    ta.sleep(1000);
                    System.out.println("-----You Chose Owner Option-----");
                    System.out.println("-----Select Your Option-----");
                    System.out.println("1.Create New Account");
                    System.out.println("2.Sign In");
                    System.out.println("3.Exit");
                    int second1 = sc.nextInt();
                    sc.nextLine();
                    new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
                    ta.sleep(750);
                    OwnerOperations ownerOperations = new OwnerOperations();
                    switch(second1)
                    {
                        case 1:
                            System.out.println("Enter NID Number");
                            int nidNo = sc.nextInt();
                            sc.nextLine();
                            ta.sleep(500);
                            System.out.println("Set User Name");
                            String userName = sc.nextLine();
                            ta.sleep(500);
                            System.out.println("Enter Full Name");
                            String fullName = sc.nextLine();
                            ta.sleep(500);
                            System.out.println("Enter Email");
                            String email = sc.nextLine();
                            ta.sleep(500);
                            System.out.println("Enter Contact Number:");
                            String contactNumber = sc.nextLine();
                            ta.sleep(500);
                            System.out.println("Set Password");
                            String password = sc.nextLine();
                            o.setNid(nidNo);
                            o.setUserName(userName);
                            o.setFullName(fullName);
                            o.setEmail(email);
                            o.setContactNumber(contactNumber);
                            o.setPassword(password);
                            System.out.print("Account Adding");
                            ta.sleep(200);
                            System.out.print(".");
                            ta.sleep(200);
                            System.out.print(".");
                            ta.sleep(200);
                            System.out.print(".");
                            ta.sleep(200);
                            System.out.println(".");
                            int flag=ownerOperations.save(o);
                            if(flag==1){
                                ta.sleep(250);
                                System.out.println("Account Added");}
                            else{ta.sleep(250);System.out.println("Account Not Added");}                        
                            break;
                        case 2:
                            System.out.println("Enter User Name:");
                            String sUserName = sc.nextLine();
                            ta.sleep(500);
                            System.out.println("Enter Password:");
                            String sPassword = sc.nextLine();
                            System.out.print("Checking");
                            ta.sleep(200);
                            System.out.print(".");
                            ta.sleep(200);
                            System.out.print(".");
                            ta.sleep(200);
                            System.out.print(".");
                            ta.sleep(200);
                            System.out.println(".");
                            if(ownerOperations.validate(sUserName, sPassword))
                            {
                                System.out.println("Login Successful");
                                boolean third1 = true;
                                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
                                System.out.println("Enter Your House Location");
                                String houseLocation = sc.nextLine();
                                ta.sleep(200);
                                System.out.println("Enter House Holding Number");
                                String holdingNumber = sc.nextLine();
                                h.setHoldingNumber(holdingNumber);
                                h.setHouseLocation(houseLocation);
                                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
                                ta.sleep(1000);
                                while(third1)
                                {
                                    System.out.println("-------Select Your Option-----");
                                    System.out.println("1.Add Flat");
                                    System.out.println("2.Manage Monthly Bill");
                                    System.out.println("3.Show All Flats");
                                    System.out.println("4.Exit");
                                    int fourth1 = sc.nextInt();
                                    sc.nextLine();
                                    new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
                                    switch(fourth1)
                                    {
                                        
                                        
                                        case 1:
                                            System.out.println("Enter Floor");
                                            int floor = sc.nextInt();
                                            System.out.println("Enter Number Of Bed Room");
                                            int bedRoom = sc.nextInt();
                                            System.out.println("Enter Number Of Bath Room");
                                            int bathRoom = sc.nextInt();
                                            System.out.println("Enter Number Of Drawing Room");
                                            int drawingRoom = sc.nextInt();
                                            System.out.println("Enter Number Of Dinning Room");
                                            int dinningRoom = sc.nextInt();
                                            System.out.println("Enter Number Of Kitchen");
                                            int kitchen = sc.nextInt();
                                            System.out.println("Enter Number Of Belcony");
                                            int belcony = sc.nextInt();
                                            System.out.println("Enter Monthly Rent");
                                            double rent = sc.nextDouble();
                                            Flat f = new Flat(floor, bedRoom, bathRoom, drawingRoom, dinningRoom, kitchen, belcony, rent,false);
                                            h.addFlat(f);
                                            frwd.writeInFile("Flat Id"+f.getRandomId()+" Floor"+floor+" BedRoom"+bedRoom+" Drawing"+drawingRoom+" Dinning"+dinningRoom+" Kitchen"+kitchen+" Belcony"+belcony+" Rent"+rent);
                                            ownerOperations.addHouse(h);
                                            break;
                                        case 2:
                                            System.out.println("Enter Flat Id:");
                                            int flatId = sc.nextInt();
                                            Flat flat = h.getFlatDetails(flatId);
                                            double flatRent = flat.getRent();
                                            System.out.println("Flat Monthly Rent:"+flatRent);
                                            System.out.println("Water Bill");
                                            double waterBill = sc.nextDouble();
                                            System.out.println("Electricity Bill");
                                            double electricBill = sc.nextDouble();
                                            System.out.println("Gas Bill");
                                            double gasBill = sc.nextDouble();
                                            System.out.println("Service Charge");
                                            double serviceCharge = sc.nextDouble();
                                            h.manageMonthlyBill(flatRent, waterBill, electricBill, gasBill, serviceCharge);
                                            break;
                                        case 3:
                                            System.out.println("Showing All Flats");
                                            h.showAllFlats();
                                            break;
                                        case 4:
                                            System.out.println("Exiting");
                                            third1=false;
                                            break;
                                        default:
                                        System.out.println("Invalid Option");
                                        break;

                                    }

                                } 
                            }
                            else{System.out.println("Check User Name And Password");}
                            break;
                        default:
                            System.out.println("Invalid Option");
                            break;
                    }
                    break;
                case 2:
                    Tenant t = new Tenant();
                    System.out.println("-----You Chose Tenant Option-----");
                    System.out.println("-----Select Your Option-----");
                    System.out.println("1.Create New Account");
                    System.out.println("2.Sign In");
                    System.out.println("3.Exit");
                    int fifth1 = sc.nextInt();
                    sc.nextLine();
                    TenantOperations tenantOperations = new TenantOperations();
                    switch(fifth1)
                    {
                        case 1:
                            System.out.println("Enter NID Number");
                            int nidNo = sc.nextInt();
                            sc.nextLine();
                            System.out.println("Set User Name");
                            String userName = sc.nextLine();
                            System.out.println("Enter Full Name");
                            String fullName = sc.nextLine();
                            System.out.println("Enter Email");
                            String email = sc.nextLine();
                            System.out.println("Enter Contact Number:");
                            String contactNumber = sc.nextLine();
                            System.out.println("Set Password");
                            String password = sc.nextLine();
                            t.setNid(nidNo);
                            t.setUserName(userName);
                            t.setFullName(fullName);
                            t.setEmail(email);
                            t.setContactNumber(contactNumber);
                            t.setPassword(password);

                            int flag = tenantOperations.save(t);
                            if(flag==1){System.out.println("Account Added");}
                            else{System.out.println("Account Not Added");}
                            break;
                        case 2:
                            System.out.println("Enter User Name:");
                            String sUserName = sc.nextLine();
                            System.out.println("Enter Password:");
                            String sPassword = sc.nextLine();
                            if(tenantOperations.validate(sUserName, sPassword))
                            {
                                System.out.println("Login Successful");
                                boolean sixth1 = true;
                                while (sixth1) {
                                    System.out.println("------Select Your Option------");
                                    System.out.println("1.Show Flat");
                                    System.out.println("2.Rent A Flat");
                                    System.out.println("3.Exit");
                                    int seventh1 = sc.nextInt();
                                    switch (seventh1) {
                                        case 1:
                                            System.out.println("-----Here Are All Flats-----");
                                            h.showHouse();
                                            break;
                                        case 2:
                                            System.out.println("Enter Flat Id");
                                            int flatId = sc.nextInt();
                                            sc.nextLine();
                                            Flat f = h.getFlatDetails(flatId);
                                            tenantOperations.rentFlat(f);
                                            break;
                                        case 3:
                                            System.out.println("Exiting....");
                                            sixth1=false;
                                            break;
                                        default:
                                            break;
                                    }
                                }
                            }
                            else{System.out.println("Check User Name And Password");}
                            break;
                        case 3:
                            System.out.println("Exiting..");
                            break;
                        default:
                            System.out.println("Invalid Option");
                            break;
                    }
                    break;
                case 3:
                    System.out.println("Exiting..");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid Option");
                    break;
            }
        }

        sc.close();
    }
}