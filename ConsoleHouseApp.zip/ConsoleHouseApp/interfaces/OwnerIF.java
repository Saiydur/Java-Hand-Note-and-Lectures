package interfaces;

import Class.*;

public interface OwnerIF {
    public void addFlat(Flat f);
    public void manageMonthlyBill(double flatRent,double waterBill,double electricBill,double gasBill,double serviceCharge);
    public void showHouse();
}
