package interfaces;

import Class.Flat;

public interface TenantIF {
    public void rentFlat(Flat f);
}
